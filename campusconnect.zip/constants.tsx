
import { Listing, MaterialItem, Scholarship } from './types';

export const MOCK_HOSTELS: Listing[] = [
  {
    id: 'h1',
    type: 'HOSTEL',
    title: 'Sunrise Boys PG',
    description: 'Affordable and clean PG with 3 meals a day. Walking distance to the main library.',
    price: '₹7,500/mo',
    distance: '0.8 km',
    rating: 4.2,
    ratingCount: 120,
    roomTypes: ['Single', 'Shared (2)'],
    image: 'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&w=400&h=300',
    address: 'Sector 15, Near Metro Station',
    contact: '9876543210',
    features: ['WiFi', 'AC', '3 Meals', 'Laundry'],
    location: { lat: 18.5204, lng: 73.8567 },
    reviews: [
      { id: 'r1', userName: 'Arjun K.', rating: 4, comment: 'Good food but rooms are slightly small.', timestamp: Date.now() - 86400000 * 2 }
    ]
  },
  {
    id: 'h2',
    type: 'HOSTEL',
    title: 'Elegant Girls Hostel',
    description: 'Safe and secure residence for female students with 24/7 security and warden.',
    price: '₹9,000/mo',
    distance: '1.2 km',
    rating: 4.8,
    ratingCount: 85,
    roomTypes: ['Single', 'Shared (3)'],
    image: 'https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?auto=format&fit=crop&w=400&h=300',
    address: 'Civil Lines, Block B',
    contact: '9123456789',
    features: ['CCTV', 'Security', 'Library', 'Power Backup'],
    location: { lat: 18.5220, lng: 73.8580 },
    reviews: [
      { id: 'r2', userName: 'Sneha P.', rating: 5, comment: 'Extremely safe and the warden is very helpful!', timestamp: Date.now() - 86400000 * 5 }
    ]
  },
  {
    id: 'h3',
    type: 'HOSTEL',
    title: 'Modern Student Living',
    description: 'Ultra-modern studio apartments for students. Includes gym and gaming zone.',
    price: '₹12,000/mo',
    distance: '2.5 km',
    rating: 4.9,
    ratingCount: 210,
    roomTypes: ['Single'],
    image: 'https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&w=400&h=300',
    address: 'Viman Nagar, Lane 7',
    contact: '9888877777',
    features: ['Gym', 'Gaming Room', 'Housekeeping'],
    location: { lat: 18.5679, lng: 73.9143 }
  }
];

export const MOCK_MESS: Listing[] = [
  {
    id: 'm1',
    type: 'MESS',
    title: 'Ghar Ka Swaad Mess',
    description: 'Pure veg home-style meals at student prices. Known for its Monday Thali.',
    price: '₹3,000/mo',
    distance: '0.5 km',
    rating: 4.5,
    ratingCount: 450,
    image: 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=400&h=300',
    address: 'Station Road, Lane 4',
    contact: '9988776655',
    features: ['Veg', 'Lunch Box', 'Sunday Special'],
    location: { lat: 18.5150, lng: 73.8550 },
    reviews: [
      { id: 'r3', userName: 'Rahul M.', rating: 5, comment: 'Tastes exactly like home food.', timestamp: Date.now() - 3600000 }
    ]
  },
  {
    id: 'm2',
    type: 'MESS',
    title: 'Spicy South Tiffin',
    description: 'Authentic South Indian breakfast and meals. Unlimited Sambar!',
    price: '₹3,500/mo',
    distance: '1.1 km',
    rating: 4.3,
    ratingCount: 320,
    image: 'https://images.unsplash.com/photo-1589302168068-964664d93dc0?auto=format&fit=crop&w=400&h=300',
    address: 'Aundh, Main Market',
    contact: '9777766666',
    features: ['South Indian', 'Quick Service'],
    location: { lat: 18.5580, lng: 73.8070 }
  }
];

export const MOCK_STATIONERY: Listing[] = [
  {
    id: 's1',
    type: 'STATIONERY',
    title: 'University Books & Prints',
    description: 'Specialized in engineering and medical textbooks. High-speed laser printing available.',
    price: 'Variable',
    distance: '0.2 km',
    rating: 4.6,
    ratingCount: 500,
    image: 'https://images.unsplash.com/photo-1456735190827-d1262f71b8a3?auto=format&fit=crop&w=400&h=300',
    address: 'Campus Main Gate, Shop 12',
    contact: '9000011111',
    features: ['Printing', 'Binding', 'New & Used Books'],
    location: { lat: 18.5210, lng: 73.8555 }
  }
];

export const MOCK_HOSPITALS: Listing[] = [
  {
    id: 'hp1',
    type: 'HOSPITAL',
    title: 'City Multi-Specialty Hospital',
    description: '24/7 emergency services. Student discount on consultations.',
    distance: '1.5 km',
    rating: 4.4,
    ratingCount: 1200,
    image: 'https://images.unsplash.com/photo-1586773860418-d374a5585a97?auto=format&fit=crop&w=400&h=300',
    address: 'Near Tech Park, North Road',
    contact: '020-22334455',
    features: ['Emergency', 'ICU', 'Pharmacy'],
    location: { lat: 18.5300, lng: 73.8600 }
  }
];

export const MOCK_EXCHANGE: MaterialItem[] = [
  {
    id: 'e1',
    title: 'Advanced Engineering Math - Kreyszig',
    category: 'BOOK',
    type: 'SELL',
    price: 450,
    ownerId: 'peer1',
    ownerName: 'Rahul Verma',
    image: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=400&h=300',
    description: 'Hardly used, 10th Edition. No markings inside.',
    contact: '9876543211'
  },
  {
    id: 'e2',
    title: 'Lab Coat (Medium)',
    category: 'LAB_COAT',
    type: 'DONATE',
    price: 0,
    ownerId: 'peer2',
    ownerName: 'Priya S.',
    image: 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&w=400&h=300',
    description: 'Clean lab coat, used for 1 semester only. Good condition.',
    contact: '9876543212'
  },
  {
    id: 'e3',
    title: 'Engineering Mechanics Notes',
    category: 'NOTES',
    type: 'SELL',
    price: 150,
    ownerId: 'peer3',
    ownerName: 'Amit Shah',
    image: 'https://images.unsplash.com/photo-1517842645767-c639042777db?auto=format&fit=crop&w=400&h=300',
    description: 'Handwritten detailed notes for first year. Covers all modules.',
    contact: '9876543213'
  }
];

export const MOCK_SCHOLARSHIPS: Scholarship[] = [
  {
    id: 'sc1',
    title: 'MahaDBT - Post Matric Scholarship (SC)',
    category: 'SC',
    deadline: 'Closing soon (Dec)',
    amount: '₹50,000',
    eligibility: 'Domicile of Maharashtra, SC category, Annual income below 2.5 Lakhs',
    link: 'https://mahadbt.maharashtra.gov.in/',
    targetCategories: ['SC']
  },
  {
    id: 'sc_st',
    title: 'MahaDBT - Post Matric Scholarship (ST)',
    category: 'ST',
    deadline: 'Ongoing',
    amount: '₹45,000',
    eligibility: 'Domicile of Maharashtra, ST category, Annual income below 2.5 Lakhs',
    link: 'https://mahadbt.maharashtra.gov.in/',
    targetCategories: ['ST']
  }
];
