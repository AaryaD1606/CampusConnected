
export type UserType = 'STUDENT' | 'PROVIDER';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  type: UserType;
  college?: string;
  degree?: string;
  area?: string;
  year?: string;
  skills?: string[];
  hobbies?: string[];
}

export interface Review {
  id: string;
  userName: string;
  rating: number;
  comment: string;
  timestamp: number;
}

export interface Listing {
  id: string;
  type: 'HOSTEL' | 'MESS' | 'STATIONERY' | 'HOSPITAL' | 'PHARMACY';
  title: string;
  description: string;
  price?: string;
  distance: string;
  rating: number;
  ratingCount: number; // For sorting
  image: string;
  address: string;
  contact: string;
  features?: string[];
  roomTypes?: string[]; // For Hostels
  location: {
    lat: number;
    lng: number;
  };
  reviews?: Review[];
}

export interface Scholarship {
  id: string;
  title: string;
  category: string;
  deadline: string;
  amount: string;
  eligibility: string;
  link: string;
  targetCategories: string[];
}

export interface MaterialItem {
  id: string;
  title: string;
  category: 'BOOK' | 'LAB_COAT' | 'NOTES' | 'EQUIPMENT' | 'OTHER';
  type: 'SELL' | 'RENT' | 'DONATE';
  price: number;
  ownerId: string;
  ownerName: string;
  image: string;
  description: string;
  contact: string;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  text: string;
  timestamp: number;
}

export interface Conversation {
  id: string;
  participantId: string;
  participantName: string;
  messages: ChatMessage[];
  lastMessage?: string;
}
