
import { GoogleGenAI, Type, Modality, Chat } from "@google/genai";

/**
 * RECO: Get smart campus recommendations based on profile
 */
export const getSmartRecommendations = async (profile: any) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Generate a short, friendly campus tip (max 15 words) for a student named ${profile.name} at ${profile.college} in ${profile.area}. Focus on student life or study spots.`,
  });
  return response.text || "Keep exploring your campus!";
};

/**
 * SKILLS: Suggest related in-demand skills based on current skills and hobbies
 */
export const getSkillSuggestions = async (skills: string[], hobbies: string[]) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const prompt = `Based on my current skills: [${skills.join(', ')}] and hobbies: [${hobbies.join(', ')}], suggest 5 specific, in-demand skills I should learn to boost my career in the current industry. Provide the name, a brief 10-word description, and a general category. Format as JSON array of objects with keys: name, description, category.`;
  
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: {
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            description: { type: Type.STRING },
            category: { type: Type.STRING }
          },
          required: ['name', 'description', 'category']
        }
      }
    }
  });
  
  try {
    return JSON.parse(response.text || '[]');
  } catch (e) {
    return [];
  }
};

/**
 * SKILLS: AI Powered search for skills/career paths
 */
export const searchSkillsAI = async (keyword: string, profile: any) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const prompt = `User is interested in: "${keyword}". User Profile: Studying ${profile.degree} at ${profile.college}. Current Skills: ${profile.skills?.join(', ')}. 
  Suggest 4 highly relevant, trending industrial skills for this career path. Return as JSON array of objects {name, description, category}.`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: {
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            description: { type: Type.STRING },
            category: { type: Type.STRING }
          },
          required: ['name', 'description', 'category']
        }
      }
    }
  });

  try {
    return JSON.parse(response.text || '[]');
  } catch (e) {
    return [];
  }
};

/**
 * GROUNDING: Search Grounding using gemini-3-flash-preview
 */
export const searchWithGrounding = async (query: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: query,
    config: { tools: [{ googleSearch: {} }] },
  });
  return {
    text: response.text,
    sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
  };
};

/**
 * GROUNDING: Maps Grounding using gemini-2.5-flash
 */
export const searchWithMaps = async (query: string, lat?: number, lng?: number) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const config: any = { tools: [{ googleMaps: {} }] };
  if (lat && lng) {
    config.toolConfig = { retrievalConfig: { latLng: { latitude: lat, longitude: lng } } };
  }
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: query,
    config
  });
  return {
    text: response.text,
    sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
  };
};

/**
 * THINKING: Complex reasoning using gemini-3-pro-preview with max budget
 */
export const thinkComplexly = async (prompt: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: prompt,
    config: { thinkingConfig: { thinkingBudget: 32768 } },
  });
  return response.text;
};

/**
 * CHAT: AI Powered Chatbot using gemini-3-pro-preview
 */
export const createAiChat = (): Chat => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  return ai.chats.create({
    model: 'gemini-3-pro-preview',
    config: {
      systemInstruction: "You are UniBot, a specialized AI assistant for college students. You help with academic planning, local services, and student life in India. Be concise, helpful, and encouraging."
    }
  });
};

/**
 * IMAGE GEN: High-quality generation with gemini-3-pro-image-preview
 */
export const generateProImage = async (prompt: string, size: '1K' | '2K' | '4K', aspectRatio: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-image-preview',
    contents: { parts: [{ text: prompt }] },
    config: { imageConfig: { imageSize: size, aspectRatio } },
  });
  const part = response.candidates?.[0]?.content?.parts.find(p => p.inlineData);
  return part?.inlineData?.data ? `data:image/png;base64,${part.inlineData.data}` : null;
};

/**
 * VIDEO GEN: Veo generation
 */
export const generateVeoVideo = async (prompt: string, aspectRatio: '16:9' | '9:16', startImage?: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const payload: any = {
    model: 'veo-3.1-fast-generate-preview',
    prompt,
    config: { numberOfVideos: 1, resolution: '720p', aspectRatio }
  };
  if (startImage) {
    payload.image = { imageBytes: startImage, mimeType: 'image/png' };
  }
  let operation = await ai.models.generateVideos(payload);
  while (!operation.done) {
    await new Promise(resolve => setTimeout(resolve, 10000));
    operation = await ai.operations.getVideosOperation({ operation: operation });
  }
  const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
  const res = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
  const blob = await res.blob();
  return URL.createObjectURL(blob);
};

/**
 * AUDIO: TTS using gemini-2.5-flash-preview-tts
 */
export const textToSpeech = async (text: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-preview-tts',
    contents: [{ parts: [{ text }] }],
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } } },
    },
  });
  return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
};

/**
 * AUDIO: Transcription using gemini-3-flash-preview
 */
export const transcribeAudio = async (base64Audio: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: {
      parts: [
        { inlineData: { data: base64Audio, mimeType: 'audio/webm' } },
        { text: "Transcribe the audio exactly. Output only the text." }
      ]
    },
  });
  return response.text;
};

/**
 * LIVE API: Helper to connect
 */
export const connectLive = (callbacks: any) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  return ai.live.connect({
    model: 'gemini-2.5-flash-native-audio-preview-12-2025',
    callbacks,
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } } },
      systemInstruction: "You are the CampusConnect Student Assistant. Help students navigate campus life, find hostels, and understand scholarship eligibility. Speak like a friendly peer."
    }
  });
};

export function encode(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

export function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}