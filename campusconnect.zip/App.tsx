
import React, { useState, useEffect, useRef } from 'react';
import Navbar from './components/Navbar';
import Sidebar from './components/Sidebar';
import ListingCard from './components/ListingCard';
import { UserProfile, Listing, Scholarship, MaterialItem, Conversation, ChatMessage, Review } from './types';
import { MOCK_HOSTELS, MOCK_MESS, MOCK_STATIONERY, MOCK_SCHOLARSHIPS, MOCK_HOSPITALS, MOCK_EXCHANGE } from './constants';
import { 
  getSmartRecommendations, 
  searchWithGrounding, 
  searchWithMaps, 
  thinkComplexly, 
  generateProImage, 
  generateVeoVideo, 
  textToSpeech, 
  connectLive,
  createAiChat,
  transcribeAudio,
  getSkillSuggestions,
  searchSkillsAI,
  encode,
  decode
} from './geminiService';
import { Chat } from "@google/genai";

declare global {
  interface AIStudio {
    hasSelectedApiKey: () => Promise<boolean>;
    openSelectKey: () => Promise<void>;
  }

  interface Window {
    aistudio?: AIStudio;
    webkitAudioContext: typeof AudioContext;
  }
}

const App: React.FC = () => {
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [activeTab, setActiveTab] = useState('home');
  const [authMode, setAuthMode] = useState<'LANDING' | 'LOGIN' | 'SIGNUP' | 'COMPLETED'>('LANDING');
  const [onboardingStep, setOnboardingStep] = useState<number>(0);
  const [tempProfile, setTempProfile] = useState<Partial<UserProfile>>({ type: 'STUDENT', skills: [], hobbies: [] });
  const [loginEmail, setLoginEmail] = useState('');
  
  const [allListings, setAllListings] = useState<Listing[]>([
    ...MOCK_HOSTELS,
    ...MOCK_MESS,
    ...MOCK_STATIONERY,
    ...MOCK_HOSPITALS
  ]);

  const [filterType, setFilterType] = useState('all');
  const [hostelBedFilter, setHostelBedFilter] = useState('all');
  const [messSortOrder, setMessSortOrder] = useState('rating');
  const [aiTip, setAiTip] = useState('Thinking about your campus life...');
  
  const [scDeadlineFilter, setScDeadlineFilter] = useState('all');
  const [scAmountFilter, setScAmountFilter] = useState('all');
  const [scCategoryFilter, setScCategoryFilter] = useState('all');
  const [onlineScholarships, setOnlineScholarships] = useState<{ text: string; sources: any[] } | null>(null);
  const [isSearchingScholarships, setIsSearchingScholarships] = useState(false);

  const [exCategoryFilter, setExCategoryFilter] = useState('all');
  const [exTypeFilter, setExTypeFilter] = useState('all');
  const [materials, setMaterials] = useState<MaterialItem[]>(MOCK_EXCHANGE);

  const [suggestedSkills, setSuggestedSkills] = useState<{name: string, description: string, category: string}[]>([]);
  const [skillSearchQuery, setSkillSearchQuery] = useState('');
  const [isSkillLoading, setIsSkillLoading] = useState(false);

  const [isAiLoading, setIsAiLoading] = useState(false);
  const [creativePrompt, setCreativePrompt] = useState('');
  const [generatedMedia, setGeneratedMedia] = useState<string | null>(null);
  const [mediaType, setMediaType] = useState<'IMAGE' | 'VIDEO' | 'TEXT' | 'AUDIO' | 'TRANSCRIBE'>('IMAGE');
  const [groundingResults, setGroundingResults] = useState<{ text: string; sources: any[] } | null>(null);
  
  const [chatHistory, setChatHistory] = useState<{ role: 'user' | 'model'; text: string }[]>([]);
  const [chatInput, setChatInput] = useState('');
  const chatRef = useRef<Chat | null>(null);
  const chatScrollRef = useRef<HTMLDivElement>(null);

  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConversationId, setActiveConversationId] = useState<string | null>(null);

  const [showAddListing, setShowAddListing] = useState(false);
  const [newListing, setNewListing] = useState<Partial<Listing>>({
    type: 'HOSTEL',
    rating: 5,
    ratingCount: 1,
    location: { lat: 18.5204, lng: 73.8567 }
  });

  // Review System States
  const [activeReviewListingId, setActiveReviewListingId] = useState<string | null>(null);
  const [reviewForm, setReviewForm] = useState({ rating: 5, comment: '' });

  useEffect(() => {
    const saved = localStorage.getItem('unilocal_profile');
    if (saved) {
      const p = JSON.parse(saved);
      setProfile(p);
      setAuthMode('COMPLETED');
      if (p.type === 'PROVIDER') setActiveTab('provider-dashboard');
    }
  }, []);

  useEffect(() => {
    if (profile && profile.type === 'STUDENT' && activeTab === 'home') {
      const fetchTip = async () => {
        try {
          const tip = await getSmartRecommendations(profile);
          setAiTip(tip);
        } catch (e) {
          console.error("AI Tip Error:", e);
        }
      };
      fetchTip();
    }
  }, [profile, activeTab]);

  useEffect(() => {
    if (activeTab === 'chat' && !chatRef.current) {
      chatRef.current = createAiChat();
    }
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
    }
    if (activeTab === 'skills' && profile && suggestedSkills.length === 0) {
      fetchSkillSuggestions();
    }
  }, [activeTab, chatHistory]);

  const fetchSkillSuggestions = async () => {
    if (!profile) return;
    setIsSkillLoading(true);
    const suggestions = await getSkillSuggestions(profile.skills || [], profile.hobbies || []);
    setSuggestedSkills(suggestions);
    setIsSkillLoading(false);
  };

  const handleSkillSearch = async () => {
    if (!skillSearchQuery.trim() || !profile) return;
    setIsSkillLoading(true);
    const suggestions = await searchSkillsAI(skillSearchQuery, profile);
    setSuggestedSkills(suggestions);
    setIsSkillLoading(false);
  };

  const handleGovScholarshipSearch = async () => {
    if (!profile) return;
    setIsSearchingScholarships(true);
    const caste = scCategoryFilter === 'all' ? 'General' : scCategoryFilter;
    const query = `List active GOVERNMENT scholarships for ${caste} category students in India 2024-2025. Include amount, eligibility, and official website links.`;
    
    try {
      const res = await searchWithGrounding(query);
      setOnlineScholarships(res);
    } catch (e) {
      alert("Error searching scholarships. Please check your API configuration.");
    }
    setIsSearchingScholarships(false);
  };

  const startConversation = (peerId: string, peerName: string) => {
    const existing = conversations.find(c => c.participantId === peerId);
    if (existing) {
      setActiveConversationId(existing.id);
    } else {
      const newConv: Conversation = {
        id: 'conv_' + Date.now(),
        participantId: peerId,
        participantName: peerName,
        messages: [],
      };
      setConversations(prev => [...prev, newConv]);
      setActiveConversationId(newConv.id);
    }
    setActiveTab('chat');
  };

  const handleLogout = () => {
    setProfile(null);
    localStorage.removeItem('unilocal_profile');
    setActiveTab('home');
    setAuthMode('LANDING');
    setOnboardingStep(0);
    setConversations([]);
    setChatHistory([]);
    setTempProfile({ type: 'STUDENT', skills: [], hobbies: [] });
  };

  const handleLogin = () => {
    const saved = localStorage.getItem('unilocal_profile');
    if (saved) {
      const savedProfile = JSON.parse(saved);
      if (savedProfile.email.toLowerCase() === loginEmail.toLowerCase()) {
        setProfile(savedProfile);
        setAuthMode('COMPLETED');
        if (savedProfile.type === 'PROVIDER') setActiveTab('provider-dashboard');
      } else {
        alert("Account not found with this email. Please Sign Up.");
      }
    } else {
      alert("No accounts found on this device. Please Sign Up.");
    }
  };

  const handleOnboardingNext = () => {
    // ENFORCED VALIDATION
    if (onboardingStep === 1) {
      if (!tempProfile.name || !tempProfile.email || !tempProfile.area) {
        alert("All fields are mandatory to proceed.");
        return;
      }
    }
    
    if (onboardingStep === 2) {
      if (tempProfile.type === 'STUDENT') {
        if (!tempProfile.college || !tempProfile.degree) {
          alert("Please fill your College and Degree details.");
          return;
        }
      } else if (tempProfile.type === 'PROVIDER') {
        if (!tempProfile.degree) {
          alert("Please select your Primary Service category.");
          return;
        }
      }
    }

    if (tempProfile.type === 'STUDENT') {
      if (onboardingStep < 3) setOnboardingStep(prev => prev + 1);
      else finishOnboarding();
    } else {
      if (onboardingStep < 2) setOnboardingStep(prev => prev + 1);
      else finishOnboarding();
    }
  };

  const finishOnboarding = () => {
    const p = { ...tempProfile, id: 'u' + Date.now() } as UserProfile;
    setProfile(p);
    localStorage.setItem('unilocal_profile', JSON.stringify(p));
    setAuthMode('COMPLETED');
    if (p.type === 'PROVIDER') setActiveTab('provider-dashboard');
  };

  const handleAddListing = () => {
    // ENFORCED VALIDATION
    if (!newListing.title || !newListing.description || !newListing.price || !newListing.image) {
      alert("All information (Title, Price, Description, Image) is necessary to fill.");
      return;
    }
    const item: Listing = {
      ...newListing,
      id: 'l' + Date.now(),
      distance: '0.1 km',
      contact: profile?.email || 'Contact through Hub',
      address: profile?.area || 'Campus Area',
      reviews: []
    } as Listing;

    setAllListings(prev => [item, ...prev]);
    setShowAddListing(false);
    setNewListing({
      type: 'HOSTEL',
      rating: 5,
      ratingCount: 1,
      location: { lat: 18.5204, lng: 73.8567 }
    });
    alert("Listing published successfully!");
  };

  const handleAddReview = () => {
    if (!reviewForm.comment.trim()) {
      alert("Remark is required.");
      return;
    }
    if (!activeReviewListingId || !profile) return;

    const newReview: Review = {
      id: 'r' + Date.now(),
      userName: profile.name,
      rating: reviewForm.rating,
      comment: reviewForm.comment,
      timestamp: Date.now()
    };

    setAllListings(prev => prev.map(listing => {
      if (listing.id === activeReviewListingId) {
        const updatedReviews = [...(listing.reviews || []), newReview];
        // Calculate new average rating
        const totalRating = updatedReviews.reduce((sum, r) => sum + r.rating, 0);
        const newAvg = parseFloat((totalRating / updatedReviews.length).toFixed(1));
        return { 
          ...listing, 
          reviews: updatedReviews, 
          rating: newAvg, 
          ratingCount: updatedReviews.length 
        };
      }
      return listing;
    }));

    setActiveReviewListingId(null);
    setReviewForm({ rating: 5, comment: '' });
    alert("Remark added! Thank you for your feedback.");
  };

  const handleChat = async () => {
    if (!chatInput.trim() || !chatRef.current) return;
    const userMessage = chatInput;
    setChatInput('');
    setChatHistory(prev => [...prev, { role: 'user', text: userMessage }]);
    try {
      const response = await chatRef.current.sendMessage({ message: userMessage });
      if (response && response.text) {
        setChatHistory(prev => [...prev, { role: 'model', text: response.text }]);
      }
    } catch (error) {
      setChatHistory(prev => [...prev, { role: 'model', text: "I'm sorry, I encountered an error." }]);
    }
  };

  const handleDirectMessage = () => {
    if (!chatInput.trim() || !activeConversationId || !profile) return;
    const msg: ChatMessage = {
      id: 'msg_' + Date.now(),
      senderId: profile.id,
      text: chatInput,
      timestamp: Date.now(),
    };
    setConversations(prev => prev.map(c => 
      c.id === activeConversationId 
        ? { ...c, messages: [...c.messages, msg], lastMessage: msg.text } 
        : c
    ));
    setChatInput('');
  };

  const filteredScholarships = MOCK_SCHOLARSHIPS.filter(sc => {
    const matchesCategory = scCategoryFilter === 'all' || sc.category.toLowerCase().includes(scCategoryFilter.toLowerCase());
    const matchesDeadline = scDeadlineFilter === 'all' || sc.deadline.toLowerCase().includes(scDeadlineFilter.toLowerCase());
    const amountVal = parseInt(sc.amount.replace(/[^0-9]/g, '')) || 0;
    const matchesAmount = scAmountFilter === 'all' || (scAmountFilter === 'high' && amountVal > 30000) || (scAmountFilter === 'low' && amountVal <= 30000);
    return matchesCategory && matchesDeadline && matchesAmount;
  });

  const filteredMaterials = materials.filter(m => {
    const matchesCategory = exCategoryFilter === 'all' || m.category === exCategoryFilter;
    const matchesType = exTypeFilter === 'all' || m.type === exTypeFilter;
    return matchesCategory && matchesType;
  });

  const sortedListings = allListings
    .filter(item => {
      if (filterType !== 'all' && item.type !== filterType) return false;
      if (item.type === 'HOSTEL' && hostelBedFilter !== 'all' && !item.roomTypes?.includes(hostelBedFilter)) return false;
      return true;
    })
    .sort((a, b) => {
      if (filterType === 'MESS') {
        if (messSortOrder === 'rating') return b.rating - a.rating;
        if (messSortOrder === 'popularity') return b.ratingCount - a.ratingCount;
      }
      return 0;
    });

  if (authMode !== 'COMPLETED') {
    return (
      <div className="min-h-screen bg-[#0f172a] flex items-center justify-center p-6 text-white font-sans overflow-hidden relative">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-indigo-600/20 blur-[120px] rounded-full"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-violet-600/20 blur-[120px] rounded-full"></div>

        <div className="max-w-md w-full z-10">
          <div className="bg-[#1e293b]/80 backdrop-blur-2xl rounded-[3rem] shadow-2xl p-10 border border-slate-700 text-center animate-in zoom-in duration-500">
            <div className="bg-gradient-to-br from-indigo-500 to-violet-600 w-20 h-20 rounded-3xl flex items-center justify-center mx-auto mb-8 shadow-2xl shadow-indigo-500/20 rotate-3">
              <i className="fas fa-university text-4xl text-white"></i>
            </div>
            
            {authMode === 'LANDING' && (
              <div className="space-y-8 animate-in fade-in duration-500">
                <div className="space-y-2">
                  <h1 className="text-4xl font-black tracking-tight">CampusConnect</h1>
                  <p className="text-slate-400 font-medium italic">"Campus life, supercharged with AI."</p>
                </div>
                <div className="space-y-4">
                  <button onClick={() => setAuthMode('SIGNUP')} className="w-full bg-indigo-600 text-white py-5 rounded-2xl font-black text-lg hover:bg-indigo-500 hover:-translate-y-1 transition-all shadow-xl shadow-indigo-600/20 flex items-center justify-center gap-3">
                    <i className="fas fa-user-plus text-sm"></i> Join Hub
                  </button>
                  <button onClick={() => setAuthMode('LOGIN')} className="w-full bg-slate-700/50 border border-slate-600 text-indigo-300 py-5 rounded-2xl font-black text-lg hover:bg-slate-700 transition-all flex items-center justify-center gap-3">
                    <i className="fas fa-sign-in-alt text-sm"></i> Sign In
                  </button>
                </div>
              </div>
            )}

            {authMode === 'LOGIN' && (
              <div className="space-y-6 animate-in slide-in-from-right-10 duration-500">
                <div className="text-left space-y-2">
                   <h2 className="text-2xl font-black">Welcome Back</h2>
                   <p className="text-slate-400 text-sm">Sign in to access your student or provider hub.</p>
                </div>
                <div className="space-y-4 text-left">
                  <div className="relative">
                    <i className="fas fa-envelope absolute left-5 top-1/2 -translate-y-1/2 text-slate-500 text-sm"></i>
                    <input 
                      type="email" 
                      placeholder="University or Business Email" 
                      className="w-full bg-slate-900/50 border border-slate-700 rounded-2xl pl-12 pr-6 py-4 font-bold outline-none focus:ring-2 focus:ring-indigo-500 transition-all text-white" 
                      value={loginEmail} 
                      onChange={e => setLoginEmail(e.target.value)} 
                    />
                  </div>
                  <button onClick={handleLogin} className="w-full bg-indigo-600 text-white py-4 rounded-2xl font-black hover:bg-indigo-500 transition-all shadow-xl shadow-indigo-600/20">
                    Sign In
                  </button>
                  <div className="flex justify-center">
                    <button onClick={() => {setAuthMode('LANDING'); setLoginEmail('')}} className="text-slate-500 font-bold text-xs uppercase tracking-widest hover:text-white transition-colors">
                      Back to Start
                    </button>
                  </div>
                </div>
              </div>
            )}

            {authMode === 'SIGNUP' && (
              <div className="space-y-6 animate-in slide-in-from-right-10 duration-500">
                <div className="flex justify-between items-center px-2">
                  <div className="flex gap-2">
                    {[0, 1, 2, 3].map(i => (
                      <div key={i} className={`h-1.5 w-6 rounded-full transition-all duration-300 ${onboardingStep >= i ? 'bg-indigo-500' : 'bg-slate-700'}`}></div>
                    ))}
                  </div>
                  <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Setup Phase</span>
                </div>

                {onboardingStep === 0 && (
                  <div className="space-y-4 text-left animate-in fade-in">
                    <h2 className="text-2xl font-black">Choose Your Role</h2>
                    <div className="grid grid-cols-1 gap-3">
                      <button onClick={() => { setTempProfile({...tempProfile, type: 'STUDENT'}); handleOnboardingNext(); }} className={`p-6 rounded-2xl border-2 transition-all text-left flex items-center gap-4 ${tempProfile.type === 'STUDENT' ? 'border-indigo-500 bg-indigo-500/10' : 'border-slate-700 hover:border-slate-600'}`}>
                        <div className="w-12 h-12 bg-indigo-600 rounded-xl flex items-center justify-center"><i className="fas fa-user-graduate"></i></div>
                        <div>
                          <p className="font-black">I am a Student</p>
                          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest text-emerald-400">Hub Explorer</p>
                        </div>
                      </button>
                      <button onClick={() => { setTempProfile({...tempProfile, type: 'PROVIDER'}); handleOnboardingNext(); }} className={`p-6 rounded-2xl border-2 transition-all text-left flex items-center gap-4 ${tempProfile.type === 'PROVIDER' ? 'border-violet-500 bg-violet-500/10' : 'border-slate-700 hover:border-slate-600'}`}>
                        <div className="w-12 h-12 bg-violet-600 rounded-xl flex items-center justify-center"><i className="fas fa-store"></i></div>
                        <div>
                          <p className="font-black">I am a Provider</p>
                          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest text-amber-400">Business Owner</p>
                        </div>
                      </button>
                    </div>
                  </div>
                )}

                {onboardingStep === 1 && (
                  <div className="space-y-4 text-left animate-in fade-in">
                    <h2 className="text-2xl font-black">{tempProfile.type === 'STUDENT' ? 'Student Identity' : 'Business Identity'}</h2>
                    <input type="text" placeholder={tempProfile.type === 'STUDENT' ? "Full Name *" : "Business / Store Name *"} className="w-full bg-slate-900 border border-slate-700 rounded-2xl px-6 py-4 font-bold outline-none focus:ring-2 focus:ring-indigo-500 transition-all text-white" value={tempProfile.name || ''} onChange={e => setTempProfile({...tempProfile, name: e.target.value})} />
                    <input type="email" placeholder="Email Address *" className="w-full bg-slate-900 border border-slate-700 rounded-2xl px-6 py-4 font-bold outline-none focus:ring-2 focus:ring-indigo-500 transition-all text-white" value={tempProfile.email || ''} onChange={e => setTempProfile({...tempProfile, email: e.target.value})} />
                    <input type="text" placeholder="Campus Area Location *" className="w-full bg-slate-900 border border-slate-700 rounded-2xl px-6 py-4 font-bold outline-none focus:ring-2 focus:ring-indigo-500 transition-all text-white" value={tempProfile.area || ''} onChange={e => setTempProfile({...tempProfile, area: e.target.value})} />
                    <p className="text-[10px] text-slate-500 font-bold italic">* Required</p>
                  </div>
                )}

                {onboardingStep === 2 && tempProfile.type === 'STUDENT' && (
                  <div className="space-y-4 text-left animate-in fade-in">
                    <h2 className="text-2xl font-black">Education</h2>
                    <input type="text" placeholder="College / University Name *" className="w-full bg-slate-900 border border-slate-700 rounded-2xl px-6 py-4 font-bold outline-none focus:ring-2 focus:ring-indigo-500 transition-all text-white" value={tempProfile.college || ''} onChange={e => setTempProfile({...tempProfile, college: e.target.value})} />
                    <input type="text" placeholder="Degree (e.g. B.Tech) *" className="w-full bg-slate-900 border border-slate-700 rounded-2xl px-6 py-4 font-bold outline-none focus:ring-2 focus:ring-indigo-500 transition-all text-white" value={tempProfile.degree || ''} onChange={e => setTempProfile({...tempProfile, degree: e.target.value})} />
                    <p className="text-[10px] text-slate-500 font-bold italic">* Required</p>
                  </div>
                )}

                {onboardingStep === 2 && tempProfile.type === 'PROVIDER' && (
                  <div className="space-y-4 text-left animate-in fade-in">
                    <h2 className="text-2xl font-black">Primary Service *</h2>
                    <p className="text-slate-400 text-sm">Select what your business primarily provides.</p>
                    <div className="grid grid-cols-2 gap-2">
                      {['HOSTEL', 'MESS', 'STATIONERY', 'HOSPITAL', 'PHARMACY'].map(cat => (
                        <button key={cat} onClick={() => setTempProfile({...tempProfile, degree: cat})} className={`p-4 rounded-xl border font-bold text-xs uppercase tracking-widest ${tempProfile.degree === cat ? 'border-indigo-500 bg-indigo-500/10 text-indigo-400' : 'border-slate-700 text-slate-500 hover:border-slate-600'}`}>
                          {cat.replace('_', ' ')}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {onboardingStep === 3 && tempProfile.type === 'STUDENT' && (
                  <div className="space-y-4 text-left animate-in fade-in">
                    <h2 className="text-2xl font-black">Interests (Optional)</h2>
                    <input type="text" placeholder="Skills (comma separated)" className="w-full bg-slate-900 border border-slate-700 rounded-2xl px-6 py-4 font-bold outline-none focus:ring-2 focus:ring-indigo-500 transition-all text-white" onChange={e => setTempProfile({...tempProfile, skills: e.target.value.split(',').map(s => s.trim())})} />
                    <input type="text" placeholder="Hobbies (comma separated)" className="w-full bg-slate-900 border border-slate-700 rounded-2xl px-6 py-4 font-bold outline-none focus:ring-2 focus:ring-indigo-500 transition-all text-white" onChange={e => setTempProfile({...tempProfile, hobbies: e.target.value.split(',').map(h => h.trim())})} />
                  </div>
                )}

                <div className="flex gap-4 pt-4">
                  {onboardingStep > 0 && <button onClick={() => setOnboardingStep(prev => prev - 1)} className="flex-1 bg-slate-700 text-white py-4 rounded-2xl font-black">Back</button>}
                  {onboardingStep > 0 && (
                    <button onClick={handleOnboardingNext} className="flex-[2] bg-indigo-600 text-white py-4 rounded-2xl font-black hover:bg-indigo-500 transition-all shadow-xl shadow-indigo-600/20">
                      Continue
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 font-sans pb-20">
      <Navbar 
        userType={profile?.type || 'STUDENT'} 
        profile={profile} 
        onLogout={handleLogout} 
        onLoginClick={() => setAuthMode('LOGIN')}
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
      />
      
      <main className="flex-1 max-w-7xl w-full mx-auto px-6 py-10">
        
        {/* REVIEW MODAL */}
        {activeReviewListingId && (
          <div className="fixed inset-0 z-[110] bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-6 animate-in fade-in">
            <div className="bg-white w-full max-w-md rounded-[3rem] p-10 shadow-2xl space-y-6 relative">
              <button onClick={() => setActiveReviewListingId(null)} className="absolute top-8 right-8 text-slate-400 hover:text-slate-600"><i className="fas fa-times text-xl"></i></button>
              <h2 className="text-3xl font-black text-slate-800">Write Remark</h2>
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Rating</label>
                  <div className="flex gap-4 justify-center text-3xl">
                    {[1, 2, 3, 4, 5].map(star => (
                      <button key={star} onClick={() => setReviewForm({...reviewForm, rating: star})} className={`transition-all ${reviewForm.rating >= star ? 'text-amber-500' : 'text-slate-200'}`}>
                        <i className="fas fa-star"></i>
                      </button>
                    ))}
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Remark / Comment</label>
                  <textarea 
                    placeholder="Share your experience..." 
                    className="w-full h-32 bg-slate-50 border border-slate-200 rounded-2xl px-4 py-3 font-bold text-sm outline-none" 
                    value={reviewForm.comment}
                    onChange={e => setReviewForm({...reviewForm, comment: e.target.value})}
                  />
                </div>
              </div>
              <button onClick={handleAddReview} className="w-full bg-indigo-600 text-white py-5 rounded-3xl font-black text-lg hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-100">Submit Feedback</button>
            </div>
          </div>
        )}

        {/* PROVIDER DASHBOARD */}
        {profile?.type === 'PROVIDER' && activeTab === 'provider-dashboard' && (
          <div className="space-y-12 animate-in fade-in duration-500">
             <div className="flex flex-col md:flex-row justify-between items-end gap-6">
                <div>
                  <h2 className="text-4xl font-black text-slate-800 mb-2">Service Provider Hub</h2>
                  <p className="text-slate-500 font-medium">Manage your listings for <strong>{profile.name}</strong>.</p>
                </div>
                <button onClick={() => setShowAddListing(true)} className="bg-indigo-600 text-white px-8 py-4 rounded-2xl font-black text-xs hover:bg-indigo-500 transition-all shadow-xl shadow-indigo-100 flex items-center gap-2">
                   <i className="fas fa-plus"></i> Add New Service
                </button>
             </div>

             <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="bg-white p-8 rounded-[2.5rem] border border-slate-200 shadow-sm text-center">
                   <div className="text-indigo-600 text-4xl font-black mb-2">{allListings.filter(l => l.contact === profile.email).length}</div>
                   <p className="text-slate-400 font-bold uppercase tracking-widest text-xs">Total Listings</p>
                </div>
                <div className="bg-white p-8 rounded-[2.5rem] border border-slate-200 shadow-sm text-center">
                   <div className="text-emerald-600 text-4xl font-black mb-2">1.2k</div>
                   <p className="text-slate-400 font-bold uppercase tracking-widest text-xs">Student Reach</p>
                </div>
                <div className="bg-white p-8 rounded-[2.5rem] border border-slate-200 shadow-sm text-center">
                   <div className="text-amber-600 text-4xl font-black mb-2">4.8</div>
                   <p className="text-slate-400 font-bold uppercase tracking-widest text-xs">Avg Rating</p>
                </div>
             </div>

             <h3 className="text-xl font-black text-slate-800 mt-12 mb-6">Manage Your Active Services</h3>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
               {allListings.filter(l => l.contact === profile.email).map(item => <ListingCard key={item.id} item={item} />)}
               {allListings.filter(l => l.contact === profile.email).length === 0 && (
                 <div className="col-span-2 py-20 bg-slate-100 rounded-[3rem] border-2 border-dashed border-slate-300 text-center text-slate-400 font-black uppercase tracking-widest">
                   <i className="fas fa-shop-slash text-5xl mb-4 block"></i>
                   You have no active services listed yet.
                 </div>
               )}
             </div>
          </div>
        )}

        {/* ADD LISTING MODAL (PROVIDER) */}
        {showAddListing && (
          <div className="fixed inset-0 z-[100] bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-6 animate-in fade-in">
             <div className="bg-white w-full max-w-2xl rounded-[3rem] p-10 shadow-2xl overflow-y-auto max-h-[90vh] space-y-6 relative">
                <button onClick={() => setShowAddListing(false)} className="absolute top-8 right-8 text-slate-400 hover:text-slate-600"><i className="fas fa-times text-xl"></i></button>
                <h2 className="text-3xl font-black text-slate-800">Add New Service</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                   <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Category *</label>
                      <select value={newListing.type} onChange={e => setNewListing({...newListing, type: e.target.value as any})} className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-4 py-3 font-bold text-sm outline-none">
                        <option value="HOSTEL">Hostel & PG</option>
                        <option value="MESS">Mess & Food</option>
                        <option value="STATIONERY">Stationery & Print</option>
                        <option value="HOSPITAL">Hospital</option>
                        <option value="PHARMACY">Medical / Pharmacy</option>
                      </select>
                   </div>
                   <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Service Name *</label>
                      <input type="text" placeholder="e.g. Skyline Girls PG" className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-4 py-3 font-bold text-sm outline-none" value={newListing.title || ''} onChange={e => setNewListing({...newListing, title: e.target.value})} />
                   </div>
                   <div className="space-y-2 md:col-span-2">
                      <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Price / Subscription Details *</label>
                      <input type="text" placeholder="e.g. ₹8,500/mo" className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-4 py-3 font-bold text-sm outline-none" value={newListing.price || ''} onChange={e => setNewListing({...newListing, price: e.target.value})} />
                   </div>
                   <div className="space-y-2 md:col-span-2">
                      <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Short Description *</label>
                      <textarea placeholder="Describe features, amenities, or specialties..." className="w-full h-32 bg-slate-50 border border-slate-200 rounded-2xl px-4 py-3 font-bold text-sm outline-none" value={newListing.description || ''} onChange={e => setNewListing({...newListing, description: e.target.value})} />
                   </div>
                   <div className="space-y-2 md:col-span-2">
                      <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Image URL *</label>
                      <input type="text" placeholder="https://..." className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-4 py-3 font-bold text-sm outline-none" value={newListing.image || ''} onChange={e => setNewListing({...newListing, image: e.target.value})} />
                   </div>
                </div>
                <button onClick={handleAddListing} className="w-full bg-indigo-600 text-white py-5 rounded-3xl font-black text-lg hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-100">Publish Listing</button>
                <p className="text-center text-[10px] text-slate-400 font-bold uppercase tracking-widest">* All information is necessary to filled</p>
             </div>
          </div>
        )}

        {/* STUDENT HOME */}
        {profile?.type === 'STUDENT' && activeTab === 'home' && (
          <div className="space-y-12 animate-in fade-in duration-500">
            <header className="bg-indigo-700 rounded-[3rem] p-12 text-white shadow-2xl relative overflow-hidden flex flex-col md:flex-row items-center gap-10">
               <div className="relative z-10 flex-1">
                 <div className="inline-flex items-center gap-2 bg-indigo-600 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest mb-6"><i className="fas fa-sparkles text-amber-400"></i> Local Campus Hub</div>
                 <h2 className="text-5xl font-black mb-4 leading-tight">Welcome, {profile?.name}.</h2>
                 <p className="text-indigo-100 text-xl font-medium mb-10 opacity-90 max-w-xl">You are registered at <strong>{profile?.college}</strong> studying <strong>{profile?.degree}</strong> in {profile?.area}.</p>
                 <div className="flex gap-4">
                   <button onClick={() => setActiveTab('listings')} className="bg-white text-indigo-700 px-8 py-4 rounded-2xl font-black shadow-lg hover:scale-105 transition-all">Browse Services</button>
                   <button onClick={() => setActiveTab('exchange')} className="bg-indigo-600 border border-white/20 px-8 py-4 rounded-2xl font-black hover:bg-indigo-500 transition-all">Exchange Gear</button>
                 </div>
               </div>
               <div className="w-full md:w-72 bg-white/10 backdrop-blur-xl border border-white/20 p-8 rounded-[2.5rem] shadow-2xl">
                  <div className="flex items-center gap-3 mb-4"><div className="bg-amber-400 p-2 rounded-lg"><i className="fas fa-lightbulb text-slate-900"></i></div><span className="text-xs font-black uppercase tracking-widest">Campus AI Tip</span></div>
                  <p className="text-sm font-bold italic leading-relaxed text-indigo-50">"{aiTip}"</p>
               </div>
            </header>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
               <div className="bg-white p-8 rounded-[2rem] border border-slate-200 flex flex-col hover:border-indigo-600 transition-all group">
                  <div className="bg-indigo-50 text-indigo-600 w-12 h-12 rounded-xl flex items-center justify-center mb-6 group-hover:bg-indigo-600 group-hover:text-white transition-colors"><i className="fas fa-graduation-cap"></i></div>
                  <h3 className="text-2xl font-black mb-2">Scholarships</h3>
                  <p className="text-slate-500 text-sm mb-6">Find government and institutional grants tailored to your profile.</p>
                  <button onClick={() => setActiveTab('scholarships')} className="mt-auto w-full py-3 bg-slate-100 rounded-xl font-black text-slate-700">Explore Grants</button>
               </div>
               <div className="bg-slate-900 p-8 rounded-[2rem] text-white flex flex-col group">
                  <div className="bg-indigo-500 text-white w-12 h-12 rounded-xl flex items-center justify-center mb-6"><i className="fas fa-exchange-alt"></i></div>
                  <h3 className="text-2xl font-black mb-2">Exchange</h3>
                  <p className="text-slate-400 text-sm mb-6">Swap books, lab coats, and notes with other students directly.</p>
                  <button onClick={() => setActiveTab('exchange')} className="mt-auto w-full py-3 bg-indigo-600 rounded-xl font-black">Peer Market</button>
               </div>
               <div className="bg-white p-8 rounded-[2rem] border border-slate-200 flex flex-col hover:border-violet-600 transition-all group">
                  <div className="bg-violet-50 text-violet-600 w-12 h-12 rounded-xl flex items-center justify-center mb-6 group-hover:bg-violet-600 group-hover:text-white transition-colors"><i className="fas fa-compass"></i></div>
                  <h3 className="text-2xl font-black mb-2">Skills</h3>
                  <p className="text-slate-500 text-sm mb-6">AI-driven guidance to learn in-demand industrial skills.</p>
                  <button onClick={() => setActiveTab('skills')} className="mt-auto w-full py-3 bg-slate-100 rounded-xl font-black text-slate-700">Career Roadmap</button>
               </div>
            </div>
          </div>
        )}

        {activeTab === 'listings' && (
          <div className="animate-in fade-in duration-500 space-y-10">
            <div className="flex flex-col md:flex-row justify-between items-end gap-6">
               <div><h2 className="text-4xl font-black text-slate-800 mb-2">Campus Services</h2><p className="text-slate-500 font-medium">Hostels, Mess, and Essential Student Services.</p></div>
               <div className="flex gap-4">
                 {filterType === 'HOSTEL' && (
                   <select value={hostelBedFilter} onChange={e => setHostelBedFilter(e.target.value)} className="bg-white border border-slate-200 px-4 py-2 rounded-xl font-bold text-sm outline-none">
                     <option value="all">Any Bed Type</option><option value="Single">Single Room</option><option value="Shared (2)">Shared (2 Bed)</option><option value="Shared (3)">Shared (3 Bed)</option>
                   </select>
                 )}
                 {filterType === 'MESS' && (
                   <select value={messSortOrder} onChange={e => setMessSortOrder(e.target.value)} className="bg-white border border-slate-200 px-4 py-2 rounded-xl font-bold text-sm outline-none">
                     <option value="rating">Sort by Rating</option><option value="popularity">Sort by Popularity</option>
                   </select>
                 )}
               </div>
            </div>
            <div className="flex flex-col lg:flex-row gap-10">
               <Sidebar filterType={filterType} setFilterType={setFilterType} />
               <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-8">
                 {sortedListings.map(item => (
                   <ListingCard 
                    key={item.id} 
                    item={item} 
                    college={profile?.college} 
                    onAddReview={profile?.type === 'STUDENT' ? (id) => setActiveReviewListingId(id) : undefined}
                  />
                 ))}
               </div>
            </div>
          </div>
        )}

        {/* EXCHANGE TAB */}
        {activeTab === 'exchange' && (
          <div className="space-y-10 animate-in fade-in duration-500">
             <div className="flex flex-col md:flex-row justify-between items-end gap-6">
                <div><h2 className="text-4xl font-black text-slate-800 mb-2">Exchange Hub</h2><p className="text-slate-500 font-medium">Swap, sell, or rent gear with fellow peers.</p></div>
                <button className="bg-slate-900 text-white px-8 py-4 rounded-2xl font-black text-xs hover:bg-slate-800 transition-all shadow-xl shadow-slate-100"><i className="fas fa-plus mr-2"></i> List Your Item</button>
             </div>
             <div className="bg-white p-6 rounded-[2rem] border border-slate-200 shadow-sm flex flex-wrap gap-6"><div className="flex-1 min-w-[200px] space-y-2"><label className="text-[10px] font-black uppercase text-slate-400 tracking-widest ml-1">Category</label><select value={exCategoryFilter} onChange={e => setExCategoryFilter(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 font-bold text-sm outline-none"><option value="all">All Items</option><option value="BOOK">Books</option><option value="LAB_COAT">Lab Coats</option><option value="NOTES">Notes</option><option value="EQUIPMENT">Equipment</option></select></div>
                <div className="flex-1 min-w-[200px] space-y-2"><label className="text-[10px] font-black uppercase text-slate-400 tracking-widest ml-1">Type</label><select value={exTypeFilter} onChange={e => setExTypeFilter(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 font-bold text-sm outline-none"><option value="all">Any Type</option><option value="SELL">Buy</option><option value="RENT">Rent</option><option value="DONATE">Free</option></select></div>
             </div>
             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {filteredMaterials.map(m => (
                  <div key={m.id} className="bg-white rounded-[2.5rem] border border-slate-200 overflow-hidden hover:shadow-2xl transition-all group flex flex-col">
                    <div className="h-56 relative"><img src={m.image} alt={m.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform" /><div className={`absolute top-4 right-4 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest text-white shadow-xl ${m.type === 'DONATE' ? 'bg-emerald-500' : m.type === 'RENT' ? 'bg-amber-500' : 'bg-indigo-600'}`}>{m.type}</div></div>
                    <div className="p-8 flex-1 flex flex-col"><h4 className="text-xl font-black mb-1 text-slate-800 line-clamp-1">{m.title}</h4><p className="text-indigo-600 font-black text-2xl mb-4">{m.price > 0 ? `₹${m.price}` : 'FREE'}</p><p className="text-slate-500 text-sm mb-6 line-clamp-3 leading-relaxed flex-1">{m.description}</p>
                       <div className="flex items-center gap-3 mb-6 p-3 bg-slate-50 rounded-2xl border border-slate-100"><div className="w-10 h-10 bg-indigo-100 rounded-full flex items-center justify-center text-indigo-600 font-black text-xs">{m.ownerName.charAt(0)}</div><div><p className="text-xs font-black text-slate-800">{m.ownerName}</p><p className="text-[10px] text-slate-400 uppercase font-bold tracking-widest">Student Peer</p></div></div>
                       <div className="flex gap-2"><button onClick={() => window.open(`tel:${m.contact}`)} className="flex-1 bg-indigo-50 text-indigo-600 py-3 rounded-2xl font-black text-xs hover:bg-indigo-100 border border-indigo-100">Call</button><button onClick={() => startConversation(m.ownerId, m.ownerName)} className="flex-1 bg-slate-900 text-white py-3 rounded-2xl font-black text-xs hover:bg-slate-800 transition-all">Chat Peer</button></div>
                    </div>
                  </div>
                ))}
             </div>
          </div>
        )}

        {/* SKILLS TAB */}
        {activeTab === 'skills' && (
           <div className="space-y-12 animate-in fade-in duration-500 pb-20">
              <div className="max-w-4xl flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
                <div><h2 className="text-4xl font-black text-slate-800 mb-4">Skill Intelligence</h2><p className="text-slate-500 font-medium text-lg leading-relaxed">AI career guidance based on your profile.</p></div>
                <div className="flex w-full md:w-auto gap-2"><input value={skillSearchQuery} onChange={e => setSkillSearchQuery(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleSkillSearch()} placeholder="Role or Path..." className="px-6 py-4 bg-white border border-slate-200 rounded-2xl font-bold text-sm shadow-sm flex-1 md:w-64 outline-none" /><button onClick={handleSkillSearch} className="bg-violet-600 text-white p-4 rounded-2xl"><i className="fas fa-search"></i></button></div>
              </div>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
                 <div className="bg-white p-10 rounded-[3rem] border border-slate-200 shadow-sm space-y-8 flex flex-col"><div className="flex-1"><h3 className="text-xl font-black text-slate-800 mb-6">Current Profile</h3><div className="space-y-6"><div><label className="text-[10px] font-black uppercase text-slate-400 tracking-widest ml-1">Skills</label><div className="flex flex-wrap gap-2 mt-2">{profile?.skills?.map((s, i) => <span key={i} className="bg-indigo-50 text-indigo-600 px-4 py-2 rounded-xl font-bold text-xs border border-indigo-100">{s}</span>)}</div></div><div><label className="text-[10px] font-black uppercase text-slate-400 tracking-widest ml-1">Hobbies</label><div className="flex flex-wrap gap-2 mt-2">{profile?.hobbies?.map((h, i) => <span key={i} className="bg-slate-100 text-slate-600 px-4 py-2 rounded-xl font-bold text-xs">{h}</span>)}</div></div></div></div><button onClick={fetchSkillSuggestions} disabled={isSkillLoading} className="w-full bg-indigo-600 text-white py-5 rounded-2xl font-black flex items-center justify-center gap-3">{isSkillLoading ? <i className="fas fa-spinner fa-spin"></i> : <i className="fas fa-sparkles"></i>} Refresh AI Guidance</button></div>
                 <div className="space-y-6"><h3 className="text-xl font-black text-slate-800 mb-4">Recommended Skills</h3>{isSkillLoading ? <div className="space-y-4">{[1, 2, 3, 4].map(i => <div key={i} className="bg-white h-32 rounded-3xl animate-pulse border border-slate-100"></div>)}</div> : suggestedSkills.length > 0 ? suggestedSkills.map((skill, idx) => (<div key={idx} className="bg-white p-6 rounded-[2rem] border border-slate-200 hover:border-indigo-600 transition-all flex items-start gap-5 group"><div className="bg-indigo-50 text-indigo-600 p-5 rounded-3xl group-hover:bg-indigo-600 group-hover:text-white transition-all"><i className="fas fa-brain text-xl"></i></div><div><h4 className="font-black text-slate-800 text-lg">{skill.name}</h4><p className="text-slate-500 text-xs font-medium mt-1 mb-3 leading-relaxed">{skill.description}</p><span className="bg-slate-100 text-[10px] font-black uppercase tracking-widest text-slate-400 px-3 py-1 rounded-lg">{skill.category}</span></div></div>)) : <div className="text-center py-24 bg-white rounded-[3rem] border-2 border-dashed border-slate-200"><p className="text-slate-400 font-black tracking-widest">Click refresh for industry trends</p></div>}</div>
              </div>
           </div>
        )}

        {/* SCHOLARSHIPS TAB */}
        {activeTab === 'scholarships' && (
          <div className="space-y-12 animate-in fade-in duration-500">
            <div className="flex flex-col md:flex-row justify-between items-end gap-6"><div className="flex-1"><h2 className="text-4xl font-black text-slate-800 mb-2">Scholarship Hub</h2><p className="text-slate-500 font-medium">Find latest GOVERNMENT grants.</p></div><button onClick={handleGovScholarshipSearch} disabled={isSearchingScholarships} className="bg-indigo-600 text-white px-8 py-4 rounded-2xl font-black text-xs flex items-center gap-2 disabled:opacity-50 shadow-lg shadow-indigo-100">{isSearchingScholarships ? <i className="fas fa-spinner fa-spin"></i> : <i className="fas fa-search"></i>} Search GOVT Scholarships</button></div>
            <div className="bg-white p-6 rounded-[2rem] border border-slate-200 shadow-sm flex flex-wrap gap-6"><div className="flex-1 min-w-[200px] space-y-2"><label className="text-[10px] font-black uppercase text-slate-400 tracking-widest ml-1">Caste / Category</label><select value={scCategoryFilter} onChange={e => setScCategoryFilter(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 font-bold text-sm outline-none"><option value="all">All / Not Specified</option><option value="General">General</option><option value="SC">SC</option><option value="ST">ST</option><option value="OBC">OBC</option><option value="Minorities">Minorities</option></select></div></div>
            {onlineScholarships && <div className="bg-indigo-50 border border-indigo-100 rounded-[3rem] p-10 animate-in slide-in-from-top-6 duration-500 shadow-inner"><div className="flex justify-between items-center mb-8"><div className="flex items-center gap-3"><div className="bg-indigo-600 text-white p-2 rounded-xl"><i className="fas fa-landmark"></i></div><h3 className="text-xl font-black text-indigo-900">Latest Government Grants Found</h3></div><button onClick={() => setOnlineScholarships(null)} className="text-indigo-400"><i className="fas fa-times"></i></button></div><div className="prose prose-indigo max-w-none text-indigo-800 font-medium whitespace-pre-wrap mb-8">{onlineScholarships.text}</div></div>}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">{filteredScholarships.map(sc => (<div key={sc.id} className="bg-white p-10 rounded-[3rem] border border-slate-200 hover:shadow-2xl transition-all flex flex-col group relative overflow-hidden"><div className="absolute top-0 right-0 px-6 py-2 bg-indigo-50 text-indigo-600 text-[10px] font-black uppercase tracking-widest rounded-bl-3xl">{sc.deadline}</div><h3 className="text-2xl font-black mb-4 group-hover:text-indigo-600 transition-colors">{sc.title}</h3><p className="text-3xl font-black text-indigo-600 mb-6">{sc.amount}</p><p className="text-slate-500 text-sm mb-10 font-medium line-clamp-3">{sc.eligibility}</p><div className="mt-auto flex gap-3"><button onClick={async () => { const res = await thinkComplexly(`Analyze eligibility for ${sc.title} for a student studying ${profile?.degree}.`); setMediaType('TEXT'); setGeneratedMedia(res); setActiveTab('studio'); }} className="flex-1 bg-indigo-50 text-indigo-600 py-4 rounded-2xl font-black text-xs hover:bg-indigo-100 border border-indigo-100">AI Analysis</button><a href={sc.link} target="_blank" rel="noopener noreferrer" className="bg-slate-900 text-white px-8 py-4 rounded-2xl font-black text-xs">Official Portal</a></div></div>))}</div>
          </div>
        )}

        {/* CHAT TAB */}
        {activeTab === 'chat' && (
          <div className="max-w-6xl mx-auto h-[75vh] flex bg-white rounded-[3rem] shadow-2xl border border-slate-200 overflow-hidden animate-in slide-in-from-bottom-10 duration-500">
             <div className="w-80 border-r border-slate-200 flex flex-col bg-slate-50/50"><div className="p-6 border-b border-slate-200 bg-white"><h3 className="font-black text-slate-800">Messages</h3></div><div className="flex-1 overflow-y-auto p-4 space-y-2"><button onClick={() => setActiveConversationId(null)} className={`w-full text-left p-4 rounded-2xl transition-all ${activeConversationId === null ? 'bg-indigo-600 text-white shadow-xl shadow-indigo-100' : 'hover:bg-white'}`}><div className="flex items-center gap-3"><div className={`p-2 rounded-xl ${activeConversationId === null ? 'bg-white/20' : 'bg-indigo-100 text-indigo-600'}`}><i className="fas fa-robot"></i></div><div><p className="text-sm font-black">UniBot AI</p></div></div></button>{conversations.map(conv => (<button key={conv.id} onClick={() => setActiveConversationId(conv.id)} className={`w-full text-left p-4 rounded-2xl transition-all ${activeConversationId === conv.id ? 'bg-indigo-600 text-white shadow-xl shadow-indigo-100' : 'hover:bg-white'}`}><div className="flex items-center gap-3"><div className={`p-2 rounded-xl ${activeConversationId === conv.id ? 'bg-white/20' : 'bg-slate-200 text-slate-600'}`}><i className="fas fa-user"></i></div><div><p className="text-sm font-black">{conv.participantName}</p><p className={`text-[10px] line-clamp-1 ${activeConversationId === conv.id ? 'text-indigo-100' : 'text-slate-400'}`}>{conv.lastMessage || 'Start peer chat'}</p></div></div></button>))}</div></div>
             <div className="flex-1 flex flex-col bg-white"><div className="bg-white p-6 border-b border-slate-200 flex justify-between items-center"><div className="flex items-center gap-3"><div className="bg-indigo-50 text-indigo-600 p-2 rounded-xl"><i className={`fas ${activeConversationId ? 'fa-user' : 'fa-robot'} text-xl`}></i></div><div><h3 className="font-black text-slate-800">{activeConversationId ? conversations.find(c => c.id === activeConversationId)?.participantName : 'UniBot Assistant'}</h3></div></div></div><div ref={chatScrollRef} className="flex-1 overflow-y-auto p-8 space-y-6 bg-slate-50/30">{!activeConversationId ? chatHistory.map((msg, i) => (<div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}><div className={`max-w-[80%] p-5 rounded-3xl font-medium shadow-sm ${msg.role === 'user' ? 'bg-indigo-600 text-white rounded-tr-none' : 'bg-white text-slate-700 rounded-tl-none border border-slate-100'}`}>{msg.text}</div></div>)) : conversations.find(c => c.id === activeConversationId)?.messages.map((msg, i) => (<div key={i} className={`flex ${msg.senderId === profile?.id ? 'justify-end' : 'justify-start'}`}><div className={`max-w-[80%] p-5 rounded-3xl font-medium shadow-sm ${msg.senderId === profile?.id ? 'bg-indigo-600 text-white rounded-tr-none' : 'bg-white text-slate-700 rounded-tl-none border border-slate-100'}`}>{msg.text}</div></div>))}</div><div className="p-6 bg-white border-t border-slate-200 flex gap-4"><input value={chatInput} onChange={e => setChatInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && (activeConversationId ? handleDirectMessage() : handleChat())} placeholder="Message..." className="flex-1 bg-slate-100 border-none rounded-2xl px-6 py-4 outline-none font-bold text-slate-800" /><button onClick={activeConversationId ? handleDirectMessage : handleChat} className="bg-indigo-600 text-white p-4 rounded-2xl hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-100"><i className="fas fa-paper-plane"></i></button></div></div>
          </div>
        )}

        {(activeTab === 'discovery' || activeTab === 'studio') && (
           <div className="animate-in fade-in py-10">
              {activeTab === 'studio' && (
                 <div className="bg-white p-10 rounded-[3rem] border border-slate-200"><h3 className="text-2xl font-black mb-6">Creative Lab</h3><div className="flex flex-wrap gap-4 mb-8">{['IMAGE', 'VIDEO', 'TEXT', 'AUDIO'].map(t => (<button key={t} onClick={() => setMediaType(t as any)} className={`px-6 py-3 rounded-2xl font-black text-xs transition-all ${mediaType === t ? 'bg-indigo-600 text-white shadow-xl' : 'bg-slate-100 text-slate-500'}`}>{t}</button>))}</div><textarea value={creativePrompt} onChange={e => setCreativePrompt(e.target.value)} placeholder="Type prompt here..." className="w-full h-40 bg-slate-50 border border-slate-200 rounded-3xl p-6 font-medium mb-6 outline-none" /><button onClick={async () => { setIsAiLoading(true); if (mediaType === 'TEXT') { const res = await thinkComplexly(creativePrompt); setGeneratedMedia(res); } setIsAiLoading(false); }} disabled={isAiLoading} className="bg-slate-900 text-white px-12 py-5 rounded-3xl font-black disabled:opacity-50 w-full">{isAiLoading ? 'Processing...' : 'Run Intelligence'}</button>{generatedMedia && <div className="mt-10 rounded-3xl overflow-hidden border border-slate-100">{mediaType === 'TEXT' && <div className="p-8 prose prose-slate max-w-none">{generatedMedia}</div>}</div>}</div>
              )}
              {activeTab === 'discovery' && groundingResults && (<div className="bg-white p-12 rounded-[3.5rem] border border-slate-100 shadow-2xl"><h2 className="text-3xl font-black mb-10">Discovery</h2><div className="prose max-w-none text-slate-700 font-medium leading-relaxed whitespace-pre-wrap">{groundingResults.text}</div></div>)}
           </div>
        )}
      </main>

      <footer className="bg-white border-t border-slate-200 py-12 text-center fixed bottom-0 left-0 right-0 z-40 px-6">
         <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-slate-400 text-[10px] font-black uppercase tracking-[0.2em]">&copy; 2025 CampusConnect Hub • Native Gemini AI Powered</p>
         </div>
      </footer>
    </div>
  );
};

export default App;