
import React from 'react';
import { UserType, UserProfile } from '../types';

interface NavbarProps {
  userType: UserType;
  profile: UserProfile | null;
  onLogout: () => void;
  onLoginClick?: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const Navbar: React.FC<NavbarProps> = ({ userType, profile, onLogout, onLoginClick, activeTab, setActiveTab }) => {
  const studentTabs = [
    { id: 'home', icon: 'house', label: 'Home' },
    { id: 'chat', icon: 'comments', label: 'AI Chat' },
    { id: 'listings', icon: 'map-location-dot', label: 'Services' },
    { id: 'scholarships', icon: 'graduation-cap', label: 'Grants' },
    { id: 'exchange', icon: 'exchange-alt', label: 'Exchange' },
    { id: 'skills', icon: 'compass', label: 'Skills' },
    { id: 'discovery', icon: 'globe', label: 'Discovery' },
    { id: 'studio', icon: 'wand-magic-sparkles', label: 'Studio' },
  ];

  const providerTabs = [
    { id: 'provider-dashboard', icon: 'chart-line', label: 'Dashboard' },
    { id: 'my-listings', icon: 'shop', label: 'My Listings' },
  ];

  const currentTabs = userType === 'STUDENT' ? studentTabs : providerTabs;

  return (
    <nav className="sticky top-0 z-50 bg-white border-b border-slate-200 shadow-sm px-4 py-3">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4">
        <div className="flex items-center gap-2 cursor-pointer" onClick={() => setActiveTab(userType === 'STUDENT' ? 'home' : 'provider-dashboard')}>
          <div className="bg-indigo-600 text-white p-2 rounded-lg">
            <i className="fas fa-university text-xl"></i>
          </div>
          <h1 className="text-xl font-bold bg-gradient-to-r from-indigo-600 to-violet-600 bg-clip-text text-transparent">
            CampusConnect
          </h1>
        </div>

        {profile && (
          <div className="flex bg-slate-100 rounded-full p-1 w-full md:w-auto overflow-x-auto scrollbar-hide no-scrollbar">
            {currentTabs.map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all whitespace-nowrap ${
                  activeTab === item.id 
                    ? 'bg-white text-indigo-600 shadow-sm' 
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                <i className={`fas fa-${item.icon}`}></i>
                {item.label}
              </button>
            ))}
          </div>
        )}

        <div className="flex items-center gap-4">
          {profile ? (
            <div className="flex items-center gap-3">
              <div className="text-right hidden sm:block">
                <p className="text-xs font-bold text-slate-800">{profile.name}</p>
                <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">{userType}</p>
              </div>
              <button 
                onClick={onLogout}
                className="text-xs px-3 py-1.5 rounded-md border border-red-100 text-red-600 bg-red-50 hover:bg-red-100 transition-colors font-bold flex items-center gap-2"
              >
                <i className="fas fa-sign-out-alt"></i> Logout
              </button>
            </div>
          ) : (
            <button 
              onClick={onLoginClick}
              className="text-sm font-bold text-indigo-600 hover:text-indigo-700 px-4 py-2 rounded-xl bg-indigo-50 border border-indigo-100 transition-all"
            >
              Sign In
            </button>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;