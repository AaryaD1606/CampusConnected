
import React, { useState } from 'react';
import { Listing, Review } from '../types';

interface ListingCardProps {
  item: Listing;
  college?: string;
  onAddReview?: (listingId: string) => void;
}

const ListingCard: React.FC<ListingCardProps> = ({ item, college, onAddReview }) => {
  const [showReviews, setShowReviews] = useState(false);
  
  const query = college 
    ? `${item.title} near ${college} ${item.address}`
    : `${item.title} ${item.address}`;
  const googleMapsUrl = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(query)}`;

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden group hover:shadow-md transition-all duration-300 flex flex-col">
      <div className="relative h-44 overflow-hidden">
        <img 
          src={item.image || 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=400&h=300'} 
          alt={item.title} 
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" 
        />
        <div className="absolute top-3 right-3 bg-white/95 backdrop-blur px-3 py-1 rounded-full text-xs font-bold text-indigo-600 shadow-sm border border-slate-100">
          {item.price ? item.price : (item.type === 'HOSPITAL' ? 'Public' : 'Contact')}
        </div>
        <div className="absolute bottom-3 left-3 flex flex-wrap gap-1">
          <span className="bg-indigo-600 text-white text-[10px] px-2.5 py-1 rounded-full font-bold uppercase tracking-wider">
            {item.type.replace('_', ' ')}
          </span>
          <span className="bg-slate-900/70 backdrop-blur text-white text-[10px] px-2.5 py-1 rounded-full font-bold">
            <i className="fas fa-route mr-1"></i> {item.distance}
          </span>
        </div>
      </div>
      <div className="p-5 flex-1 flex flex-col">
        <div className="flex justify-between items-start mb-2">
          <h3 className="font-bold text-slate-800 text-lg leading-tight group-hover:text-indigo-600 transition-colors">{item.title}</h3>
          <div className="flex flex-col items-end">
            <div className="flex items-center text-amber-500 text-sm bg-amber-50 px-2 py-0.5 rounded-lg border border-amber-100">
              <i className="fas fa-star mr-1"></i>
              <span className="font-bold text-amber-700">{item.rating}</span>
            </div>
            <span className="text-[10px] text-slate-400 font-bold mt-1 uppercase tracking-tighter">{item.ratingCount} Ratings</span>
          </div>
        </div>
        <p className="text-slate-500 text-xs mb-4 line-clamp-2 leading-relaxed">{item.description}</p>
        
        <div className="flex items-start gap-2 text-slate-400 text-xs mb-5">
          <i className="fas fa-map-marker-alt mt-0.5 text-indigo-400"></i>
          <span className="line-clamp-1">{item.address}</span>
        </div>

        <div className="mt-auto space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <a 
              href={`tel:${item.contact}`}
              className="bg-indigo-50 text-indigo-600 py-2.5 rounded-xl text-xs font-bold hover:bg-indigo-100 transition-colors border border-indigo-100 flex items-center justify-center gap-2"
            >
              <i className="fas fa-phone-alt"></i> Call
            </a>
            <a 
              href={googleMapsUrl} 
              target="_blank" 
              rel="noopener noreferrer"
              className="bg-indigo-600 text-white py-2.5 rounded-xl text-xs font-bold hover:bg-indigo-700 transition-all text-center flex items-center justify-center gap-2 shadow-lg shadow-indigo-100"
            >
              <i className="fas fa-directions"></i> Directions
            </a>
          </div>
          
          <div className="flex gap-2">
            <button 
              onClick={() => setShowReviews(!showReviews)}
              className="flex-1 py-2 text-[10px] font-black uppercase tracking-widest text-slate-400 hover:text-indigo-600 transition-colors border-t border-slate-100 pt-3"
            >
              {showReviews ? 'Hide' : 'View'} Remarks ({item.reviews?.length || 0})
            </button>
            {onAddReview && (
              <button 
                onClick={() => onAddReview(item.id)}
                className="py-2 text-[10px] font-black uppercase tracking-widest text-indigo-500 hover:text-indigo-700 transition-colors border-t border-slate-100 pt-3"
              >
                + Write Remark
              </button>
            )}
          </div>
        </div>

        {showReviews && (
          <div className="mt-4 pt-4 border-t border-slate-50 space-y-3 animate-in slide-in-from-top-2 duration-300">
            {item.reviews && item.reviews.length > 0 ? item.reviews.map(review => (
              <div key={review.id} className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                <div className="flex justify-between items-center mb-1">
                  <span className="font-bold text-slate-800 text-[11px]">{review.userName}</span>
                  <div className="flex text-amber-500 text-[10px]">
                    {[1, 2, 3, 4, 5].map(star => (
                      <i key={star} className={`fas fa-star ${star <= review.rating ? '' : 'opacity-20'}`}></i>
                    ))}
                  </div>
                </div>
                <p className="text-slate-500 text-[11px] leading-relaxed italic">"{review.comment}"</p>
              </div>
            )) : (
              <p className="text-center text-[10px] text-slate-400 py-2">No remarks yet.</p>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default ListingCard;
