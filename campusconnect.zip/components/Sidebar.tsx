
import React from 'react';

interface SidebarProps {
  filterType: string;
  setFilterType: (type: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ filterType, setFilterType }) => {
  const categories = [
    { id: 'all', label: 'All Services', icon: 'list' },
    { id: 'HOSTEL', label: 'Hostels & PG', icon: 'bed' },
    { id: 'MESS', label: 'Mess & Food', icon: 'utensils' },
    { id: 'STATIONERY', label: 'Stationery & Print', icon: 'pen-nib' },
    { id: 'HOSPITAL', label: 'Hospitals', icon: 'hospital' },
    { id: 'PHARMACY', label: 'Medical & Pharmacy', icon: 'pills' },
  ];

  return (
    <aside className="w-full lg:w-64 flex-shrink-0 space-y-6">
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4">
        <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-4">Categories</h3>
        <div className="space-y-1">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setFilterType(cat.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                filterType === cat.id
                  ? 'bg-indigo-50 text-indigo-700'
                  : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              <i className={`fas fa-${cat.icon} w-5 text-center`}></i>
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      <div className="bg-indigo-600 rounded-xl p-6 text-white shadow-lg overflow-hidden relative">
        <div className="relative z-10">
          <h4 className="font-bold text-lg mb-2">Need Help?</h4>
          <p className="text-indigo-100 text-sm mb-4">Ask UniBot for AI recommendations based on your area.</p>
          <button className="bg-white text-indigo-600 px-4 py-2 rounded-lg text-sm font-bold w-full hover:bg-indigo-50 transition-colors">
            Ask UniBot
          </button>
        </div>
        <div className="absolute -bottom-4 -right-4 opacity-10">
          <i className="fas fa-robot text-8xl"></i>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
